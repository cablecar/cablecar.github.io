Flat UI Pro 1.2.1
=======

Flat UI Pro

Make money by partnering with Designmodo and earn 25% Commission Per Sale! Just add "Powered by Flat UI" in your site footer and link it to affiliate link. 
Learn more http://designmodo.com/affiliates/

Thanks for supporting our website and enjoy!

Links:
http://designmodo.com/flat


## Authors

**Sergey Shmidt**

+ [http://shmidt.in](http://shmidt.in)
+ [http://twitter.com/monstercritic](http://twitter.com/monstercritic)

**Sergii Iurevych**

+ [http://twitter.com/iurevych](http://twitter.com/iurevych)
+ [http://github.com/iurevych](http://github.com/iurevych)

## Typeface
Flat UI Free is made using the Lato typeface, which can be downloaded for free here: http://www.google.com/webfonts/specimen/Lato
